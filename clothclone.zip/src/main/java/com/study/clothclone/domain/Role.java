package com.study.clothclone.domain;

public class Role {
}
