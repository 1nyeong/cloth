package com.study.clothclone.dto.validation;

public interface ValidationGroups {
    public interface NotBlankGroup {};
    public interface SizeGroup {};
    public interface PatternCheckGroup {};
}

