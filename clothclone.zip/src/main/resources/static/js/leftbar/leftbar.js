const loginButton = document.querySelector(".login");

loginButton.onclick = () => {
    location.href = "/login";
}

const registerButton = document.querySelector(".register");

registerButton.onclick = () => {
    location.href = "/register";
}

const cartButton = document.querySelector(".cart");

cartButton.onclick = () => {
    location.href = "/cart";
}

const noticeButton = document.querySelector(".notice");

noticeButton.onclick = () => {
    location.href = "/notice";
}

const boardlistButton = document.querySelector(".boardlist");

boardlistButton.onclick = () => {
    location.href = "/boardlist";
}


const newButton = document.querySelector(".all");

newButton.onclick = () => {
    location.href = "/all";
}

const outerButton = document.querySelector(".outer");

outerButton.onclick = () => {
    location.href = "/outer";
}

const topButton = document.querySelector(".top");

topButton.onclick = () => {
    location.href = "/top";
}

const pantsButton = document.querySelector(".pants");

pantsButton.onclick = () => {
    location.href = "/pants";
}

const bagshoesButton = document.querySelector(".bag&shoes");

bagshoesButton.onclick = () => {
    location.href = "/bag&shoes";
}
const accButton = document.querySelector(".acc");

accButton.onclick = () => {
    location.href = "/acc";
}