package com.study.clothclone;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClothcloneApplicationTests {

	@Test
	void contextLoads() {
	}

}
