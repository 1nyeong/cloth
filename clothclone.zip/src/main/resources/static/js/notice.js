const BoardButton = document.querySelector(".button-board");

BoardButton.onclick = () => {
    location.href = "/notice";
}

const writeButton = document.querySelector(".btn-a");

writeButton.onclick = () => {
    location.href = "/notice";
}   